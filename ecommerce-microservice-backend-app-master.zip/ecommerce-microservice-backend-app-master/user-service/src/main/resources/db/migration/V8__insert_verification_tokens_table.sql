
INSERT INTO verification_tokens
(credential_id, verif_token, expire_date) VALUES
(1, '', '2026-12-31'),
(2, '', '2026-12-31'),
(3, '', '2026-12-31'),
(4, '', '2026-12-31');


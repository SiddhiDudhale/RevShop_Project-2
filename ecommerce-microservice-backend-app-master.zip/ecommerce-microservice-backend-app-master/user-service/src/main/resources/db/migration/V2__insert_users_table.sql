
INSERT INTO users
(first_name, last_name) VALUES
('selim', 'horri'),
('amine', 'ladjimi'),
('omar', 'derouiche'),
('admin', 'admin');



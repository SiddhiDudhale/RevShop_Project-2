
INSERT INTO credentials
(user_id, username, password, role, is_enabled) VALUES
(1, 'selimhorri', '$2a$12$kc.PXrDXd9xTvysTIvGQyuwyAkLCAAJGbJ4f4QOhw8J6gIwNZ2MiO', 'ROLE_USER', true),
(2, 'amineladjimi', '$2a$12$kc.PXrDXd9xTvysTIvGQyuwyAkLCAAJGbJ4f4QOhw8J6gIwNZ2MiO', 'ROLE_USER', true),
(3, 'omarderouiche', '$2a$12$kc.PXrDXd9xTvysTIvGQyuwyAkLCAAJGbJ4f4QOhw8J6gIwNZ2MiO', 'ROLE_USER', true),
(4, 'admin', '$2a$12$kc.PXrDXd9xTvysTIvGQyuwyAkLCAAJGbJ4f4QOhw8J6gIwNZ2MiO', 'ROLE_USER', true);

